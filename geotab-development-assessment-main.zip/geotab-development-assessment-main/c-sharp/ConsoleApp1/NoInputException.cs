﻿using System;

namespace JokeGenerator
{
    public class NoInputException: Exception
    {
        public NoInputException() 
        { 

        }

        public NoInputException(string message) : base(message)
        { 

        }
    }
}

﻿using JokeGenerator.Wrappers;
using Ninject.Modules;

namespace JokeGenerator.DI
{
    public class DependencyResolver : NinjectModule
    {
        public override void Load()
        {
            Bind<IConsoleWrapper>().To<ConsoleWrapper>();
            Bind<IProgramWrapper>().To<ProgramWrapper>();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using JokeGenerator.Wrappers;
using Microsoft.VisualStudio.TestPlatform.Utilities;

namespace JokeGenerator.DI
{
    public class ConsoleStub : ConsoleWrapperBase, IDisposable
    {

        private List<string> _outputs = new List<string>();
        private bool disposedValue;

        public Queue<object> UserInputs { get; } = new Queue<object>();

        public override void Clear()
        {
            _outputs.Clear();
        }

        public override async Task<char?> ReadKeyCharAsync(CancellationToken cancellationToken)
        {
            char? result;

            if (UserInputs.Count > 0)
            {
                result = await Task.Run<char?>(async () =>
                {
                    while (!cancellationToken.IsCancellationRequested)
                    {
                        await Task.Delay(100);
                        if (UserInputs.Count > 0)
                        {
                            var read = UserInputs.Dequeue();
                            return ((ConsoleKeyInfo)read).KeyChar;
                        }
                    }
                    cancellationToken.ThrowIfCancellationRequested();
                    return ' ';
                }, cancellationToken);
            }
            else
            {
                throw new NoInputException("No input was presented when an input was expected");
            }

            return await Task.FromResult(result);
        }
        public override void WriteLine(string value)
        {
            _outputs.Add(value + "\r\n");
        }
        public override string ToString()
        {
            var result = string.Empty;

            if (_outputs == null || _outputs.Count <= 0) return result;

            var builder = new StringBuilder();

            foreach (var output in _outputs)
            {
                builder.Append(output);
            }

            result = builder.ToString();

            return result;
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    //no managed objects, so empty placeholder
                }
                _outputs.Clear();
                _outputs = null;
                disposedValue = true;
            }
        }
        public void Dispose()
        {
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }
}

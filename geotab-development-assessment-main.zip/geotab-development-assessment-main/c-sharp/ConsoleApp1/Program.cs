﻿using JokeGenerator.Wrappers;
using Ninject;
using System.Reflection;
using System.Threading;

namespace JokeGenerator
{
    class Program
    {

        private static IProgramWrapper programWrapper = null;

        static void Main(string[] args)
        {
            var kernel = new StandardKernel();
            kernel.Load(Assembly.GetExecutingAssembly());

            var cancellationToken = new CancellationToken();
            programWrapper = kernel.Get<IProgramWrapper>();
            programWrapper.RunAsync(cancellationToken).Wait();
        }
    }
}

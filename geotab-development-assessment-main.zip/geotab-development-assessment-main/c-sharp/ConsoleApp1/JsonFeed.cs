﻿using System;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace JokeGenerator
{
    class JsonFeed
    {
        static string _url = "";
        static int _count = 1;
        public JsonFeed() { }
        public JsonFeed(string endpoint, int count)
        {
            _url = endpoint;
            _count = count;
        }
        
		public static string[] GetRandomJokes(string category)
		{
            var results = new string[_count];
            HttpClient client = new HttpClient();
			client.BaseAddress = new Uri(_url);
			string url = string.Empty;
			if (category != null)
			{
				url += "?";
				url += "category=";
				url += category;
			}

            var index = 0;
            while(index < results.Length)
            {
                string joke = Task.FromResult(client.GetStringAsync(url).Result).Result;
                var j = JsonConvert.DeserializeObject<dynamic>(joke).value;
                if (!results.Any(x => !string.IsNullOrEmpty(x) && x.Equals(j.ToString())))
                {
                    results[index] = $"[{j.ToString()}]";
                    index++;
                }
            }
            return results;
        }

		public static string[] GetCategories()
		{
			var client = new HttpClient();
			var categories = JArray.Parse(Task.FromResult(client.GetStringAsync(new Uri(_url)).Result).Result).Select(x => x.ToString());
            return categories.ToArray();
		}
    }
}

﻿using System;
using System.Threading.Tasks;
using System.Threading;

namespace JokeGenerator.Wrappers
{
    public interface IConsoleWrapper
    {
        void WriteLine(string value);
        Task<char?> ReadKeyCharAsync(CancellationToken cancellationToken);
        void Clear();
    }
}

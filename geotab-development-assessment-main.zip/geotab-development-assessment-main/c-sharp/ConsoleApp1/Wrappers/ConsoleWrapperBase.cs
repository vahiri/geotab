﻿using System;
using System.Threading.Tasks;
using System.Threading;
using System.Reflection.Metadata;

namespace JokeGenerator.Wrappers
{
    public abstract class ConsoleWrapperBase : IConsoleWrapper
    {
        public abstract void Clear();
        public virtual async Task<char?> ReadKeyCharAsync(CancellationToken cancellationToken)
        {
            return await Task.FromResult<char?>(null);
        }
        public abstract void WriteLine(string value);
    }
}

﻿using System;
using System.Threading.Tasks;
using System.Threading;

namespace JokeGenerator.Wrappers
{
    public class ConsoleWrapper : ConsoleWrapperBase
    {
        public override void Clear()
        {
            Console.Clear();
        }

        public override async Task<char?> ReadKeyCharAsync(CancellationToken cancellationToken)
        {
            if (Console.KeyAvailable)
            {
                var read = Console.ReadKey(false);
                return read.KeyChar;
            }
            var result = await Task.Run<char?>(async () =>
            {
                while (!cancellationToken.IsCancellationRequested)
                {
                    await Task.Delay(100);
                    if (Console.KeyAvailable)
                    {
                        var read = Console.ReadKey(false);
                        return read.KeyChar;
                    }
                }
                cancellationToken.ThrowIfCancellationRequested();
                return null;
            }, cancellationToken);
            return result;
        }

        public override void WriteLine(string value)
        {
            Console.WriteLine(value);
        }
    }
}

﻿using System.Threading;
using System.Threading.Tasks;

namespace JokeGenerator.Wrappers
{
    public interface IProgramWrapper
    {
        Task<int?> RunAsync(CancellationToken cancellationToken);
        Task<string> GetCategoryAsync(CancellationToken cancellationToken);
        Task<int> GetJokeCountAsync(CancellationToken cancellationToken);
    }
}

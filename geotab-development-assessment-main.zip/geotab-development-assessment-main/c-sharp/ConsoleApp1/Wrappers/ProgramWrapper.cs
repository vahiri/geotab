﻿using Microsoft.VisualStudio.TestPlatform.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace JokeGenerator.Wrappers
{
    public class ProgramWrapper : ProgramWrapperBase, IDisposable
    {
        static string[] results = new string[9];
        static Dictionary<int, string> categories = new Dictionary<int, string>();
        static char? keyChar;
        private readonly IConsoleWrapper _console;
        private bool disposedValue;

        public ProgramWrapper(IConsoleWrapper console)
        {
            _console = console;
        }
        public override async Task<int?> RunAsync(CancellationToken cancellationToken)
        {
            _console.WriteLine("Press ? to get instructions.");
            while (true)
            {
                keyChar = await _console.ReadKeyCharAsync(cancellationToken);
                if (keyChar.HasValue && keyChar == 'c')
                {
                    if (categories.Count == 0)
                    {
                        PlotCategories();
                    }
                }
                else if (keyChar.HasValue && keyChar == 'r')
                {
                    _console.WriteLine("Want to specify a category? y/n");
                    var isCategoryCleared = false;
                    while (!isCategoryCleared)
                    {
                        keyChar = await _console.ReadKeyCharAsync(cancellationToken);
                        if (keyChar.HasValue && keyChar == 'y')
                        {
                            isCategoryCleared = true;
                            if (categories.Count == 0)
                            {
                                PlotCategories();
                            }
                            var category = await GetCategoryAsync(cancellationToken);
                            var jokeCount = await GetJokeCountAsync(cancellationToken);
                            GetRandomJokes(category, jokeCount);
                            PrintResults();
                            return results.Length;
                        }
                        else if (keyChar.HasValue && keyChar == 'n')
                        {
                            isCategoryCleared = true;
                            var jokeCount = await GetJokeCountAsync(cancellationToken);
                            GetRandomJokes(null, jokeCount);
                            return results.Length;
                        }
                        else
                        {
                            _console.WriteLine("Invalid answer.");
                        }
                    }
                }
                else if (keyChar.HasValue && keyChar == '?')
                {
                    _console.WriteLine("Press c to get categories");
                    _console.WriteLine("Press r to get random jokes");
                }
                else
                {
                    _console.WriteLine("Unrecognized character.");
                    return 0;
                }
            }
        }
        public override async Task<string> GetCategoryAsync(CancellationToken cancellationToken)
        {
            if (categories.Count == 0)
            {
                PlotCategories();
            }
            _console.WriteLine("Enter a category index starting with 1");
            var categoryIndex = 0;
            while (!int.TryParse((await _console.ReadKeyCharAsync(cancellationToken)).ToString(), out categoryIndex) || categoryIndex < 1 || categoryIndex >= categories.Count)
            {
                _console.WriteLine($"Invalid value. Please use number between 1 and {categories.Count}");
            }

            var category = categories[categoryIndex - 1];
            return category;
        }
        public override async Task<int> GetJokeCountAsync(CancellationToken cancellationToken)
        {
            _console.WriteLine("How many jokes do you want? (1-9)");
            int jokeCount = 0;
            while (!int.TryParse((await _console.ReadKeyCharAsync(cancellationToken)).ToString(), out jokeCount) || jokeCount < 1 || jokeCount > 9)
            {
                _console.WriteLine($"Invalid value. Please use number between 1 and 9");
            }
            return jokeCount;
        }
        private void PlotCategories()
        {
            GetCategories();
            PrintResults();
            categories = results.Select((value, index) => new { value, index }).ToDictionary(pair => pair.index, pair => pair.value);
        }
        private void PrintResults()
        {
            _console.WriteLine("[" + string.Join(",", results) + "]");
        }
        private void GetRandomJokes(string category, int number)
        {
            new JsonFeed("https://us-central1-geotab-interviews.cloudfunctions.net/joke", number);
            results = JsonFeed.GetRandomJokes(category);
        }
        private void GetCategories()
        {
            new JsonFeed("https://us-central1-geotab-interviews.cloudfunctions.net/joke_category", 0);
            results = JsonFeed.GetCategories();
        }
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    //no managed objects, so empty placeholder
                }
                results = null;
                disposedValue = true;
            }
        }
        public void Dispose()
        {
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }
}

﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace JokeGenerator.Wrappers
{
    public abstract class ProgramWrapperBase : IProgramWrapper
    {
        public virtual async Task<int?> RunAsync(CancellationToken cancellationToken)
        {
            return await Task.FromResult<int?>(null);
        }

        public virtual async Task<string> GetCategoryAsync(CancellationToken cancellationToken)
        {
            return await Task.FromResult<string>(null);
        }
        public virtual async Task<int> GetJokeCountAsync(CancellationToken cancellationToken)
        {
            return await Task.FromResult<int>(0);
        }
    }
}

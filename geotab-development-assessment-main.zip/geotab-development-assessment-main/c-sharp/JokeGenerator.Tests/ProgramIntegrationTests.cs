﻿using JokeGenerator.DI;
using JokeGenerator.Wrappers;
using NUnit.Framework.Legacy;

namespace JokeGenerator
{
    /// <summary>
    ///  Idea of integration tests to simulate the entire workflow of user input.
    /// </summary>
    public class ProgramIntegrationTests
    {
        private ConsoleStub _console;
        private ProgramWrapper _program;

        [SetUp]
        public void SetUp()
        {
            _console = new ConsoleStub();
            _program = new ProgramWrapper(_console);
        }

        [TearDown]
        public void TearDown()
        {
            _program.Dispose();
            _console.Dispose();
        }

        private static char[][] _sucessfulTestCaseSources = [['c', 'r', 'y', '1', '4'], ['r', 'n', '1']];

        private static char[][] _timeoutTestCaseSources = [['?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?']];

        private static char[][] _invalidStateMachineTestCaseSources = [['r', 'y', '1']];

        /// <summary>
        ///  
        ///    This one test is simulating few valid workflows.
        /// </summary>
        /// <param name="sequenceOfCharacters">sequence defined in _sucessfulTestCaseSources function</param>
        [Test, TestCaseSource(nameof(_sucessfulTestCaseSources))]
        public async Task RunSuccessWorkflowTestAsync(char[] sequenceOfCharacters)
        {
            foreach(var character in sequenceOfCharacters)
            {
                _console.UserInputs.Enqueue(new ConsoleKeyInfo(character, (ConsoleKey)character, false, false, false));
            }
            using (var timoutCancellationTokenSource = new CancellationTokenSource())
            {
                timoutCancellationTokenSource.CancelAfter(5000);
                var result = await _program.RunAsync(timoutCancellationTokenSource.Token);
                ClassicAssert.Greater(result, 0);
            }
        }

        /// <summary>
        ///    This one test is simulating a failure due to invalid state machine workflow.
        /// </summary>
        /// <param name="sequenceOfCharacters">sequence defined in _timeoutTestCaseSources function</param>
        [Test, TestCaseSource(nameof(_timeoutTestCaseSources))]
        public void RunTimeoutWorkflowTest(char[] sequenceOfCharacters)
        {
            foreach (var character in sequenceOfCharacters)
            {
                _console.UserInputs.Enqueue(new ConsoleKeyInfo(character, (ConsoleKey)character, false, false, false));
            }
            using (var timoutCancellationTokenSource = new CancellationTokenSource())
            {
                timoutCancellationTokenSource.CancelAfter(300);
                Assert.That(async() => await _program.RunAsync(timoutCancellationTokenSource.Token), Throws.InstanceOf<TaskCanceledException>());
            }
        }

        /// <summary>
        ///    This one test is simulating a failure due to invalid state machine workflow.
        /// </summary>
        /// <param name="sequenceOfCharacters">sequence defined in _invalidStateMachineTestCaseSources function</param>
        [Test, TestCaseSource(nameof(_invalidStateMachineTestCaseSources))]
        public void RunInvalidWorkflowTest(char[] sequenceOfCharacters)
        {
            foreach (var character in sequenceOfCharacters)
            {
                _console.UserInputs.Enqueue(new ConsoleKeyInfo(character, (ConsoleKey)character, false, false, false));
            }
            using (var timoutCancellationTokenSource = new CancellationTokenSource())
            {
                timoutCancellationTokenSource.CancelAfter(3000);
                Assert.That(async () => await _program.RunAsync(timoutCancellationTokenSource.Token), Throws.InstanceOf<NoInputException>());
            }
        }
    }
}
﻿using JokeGenerator.DI;
using JokeGenerator.Wrappers;
using NUnit.Framework.Legacy;

namespace JokeGenerator
{
    public class ProgramUnitTests
    {
        private ConsoleStub _console;
        private ProgramWrapper _program;

        [SetUp]
        public void SetUp()
        {
            _console = new ConsoleStub();
            _program = new ProgramWrapper(_console);
        }

        [TearDown]
        public void TearDown()
        {
            _program.Dispose();
            _console.Dispose();
        }

        private static char[] _sucessfulCategoriesTestCaseSources = ['1', '5', '3'];

        private static char[] _invalidCategoriesTestCaseSources = ['0', '9', 't'];

        private static char[] _sucessfulCountTestCaseSources = ['1', '4', '7'];

        private static char[] _invalidCountTestCaseSources = ['0', 'c'];

        /// <summary>
        ///  
        ///    This one test is simulating few valid tests.
        /// </summary>
        /// <param name="character">valid categories</param>
        [Test, TestCaseSource(nameof(_sucessfulCategoriesTestCaseSources))]
        public async Task RunSuccessGetCategoriesTestAsync(char character)
        {
            _console.UserInputs.Enqueue(new ConsoleKeyInfo(character, (ConsoleKey)character, false, false, false));
            using (var timoutCancellationTokenSource = new CancellationTokenSource())
            {
                timoutCancellationTokenSource.CancelAfter(30000);
                var result = await _program.GetCategoryAsync(timoutCancellationTokenSource.Token);
                ClassicAssert.Greater(result.Length, 0);
            }
        }

        /// <summary>
        ///  
        ///    This one test is simulating few invalid tests.
        /// </summary>
        /// <param name="character">invalid categories</param>
        [Test, TestCaseSource(nameof(_invalidCategoriesTestCaseSources))]
        public async Task RunFailedGetCategoriesTestAsync(char character)
        {
            _console.UserInputs.Enqueue(new ConsoleKeyInfo(character, (ConsoleKey)character, false, false, false));
            using (var timoutCancellationTokenSource = new CancellationTokenSource())
            {
                timoutCancellationTokenSource.CancelAfter(3000);
                Assert.That(async () => await _program.GetCategoryAsync(timoutCancellationTokenSource.Token), Throws.InstanceOf<NoInputException>());
            }
        }

        /// <summary>
        ///  
        ///    This one test is simulating few valid tests.
        /// </summary>
        /// <param name="character">valid categories</param>
        [Test, TestCaseSource(nameof(_sucessfulCountTestCaseSources))]
        public async Task RunSuccessGetJokesTestAsync(char character)
        {
            _console.UserInputs.Enqueue(new ConsoleKeyInfo(character, (ConsoleKey)character, false, false, false));
            using (var timoutCancellationTokenSource = new CancellationTokenSource())
            {
                timoutCancellationTokenSource.CancelAfter(30000);
                var result = await _program.GetJokeCountAsync(timoutCancellationTokenSource.Token);
                ClassicAssert.Greater(result, 0);
            }
        }

        /// <summary>
        ///  
        ///    This one test is simulating few invalid tests.
        /// </summary>
        /// <param name="character">invalid categories</param>
        [Test, TestCaseSource(nameof(_invalidCountTestCaseSources))]
        public async Task RunFailedGetJokesTestAsync(char character)
        {
            _console.UserInputs.Enqueue(new ConsoleKeyInfo(character, (ConsoleKey)character, false, false, false));
            using (var timoutCancellationTokenSource = new CancellationTokenSource())
            {
                timoutCancellationTokenSource.CancelAfter(3000);
                Assert.That(async () => await _program.GetJokeCountAsync(timoutCancellationTokenSource.Token), Throws.InstanceOf<NoInputException>());
            }
        }
    }
}
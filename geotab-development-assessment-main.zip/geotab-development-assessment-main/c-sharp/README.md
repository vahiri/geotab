# C# version #

## What do I need? ##

* [.NET](https://dotnet.microsoft.com/en-us/download) - any platform
* Your IDE of choice
# What's new in new release
## 13/06/2024

# In this release
## Package upgrade
## Syntax and stylistic fixes
## Wrapper functionality
## Added Console Stub
## Generic integration testing

### Package upgrade
- Upgraded Newtonsoft.Json due to vulnerability warning.

### Syntax and stylistic fixes
- Fixed several method, variable names that were not matching common casing.

### Wrapper functionality
- Added wrappers for console and program to allow dependency injection and testing

### Added Console Stub
- Added console stub to be used in unit and integration testing

### Generic integration and unit testing
- Added methods to integration test user input workflows, any character combinations can be added and tested without much difficulty